/*
 * Copyright (c) 2020 Nanjing Xiaoxiongpai Intelligent Technology Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <cJSON.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"

#include "wifi_connect.h"
#include <queue.h>
#include "E53_IA1.h"
#include "lwip/sockets.h"
#include "wifi_device.h"
#include "lwip/netifapi.h"
#include "lwip/api_shell.h"
#include "nfc_app.h"

#define CONFIG_WIFI_SSID          ssid                            //修改为自己的WiFi 热点账号

#define CONFIG_WIFI_PWD           "12345678"                        //修改为自己的WiFi 热点密码

#define CONFIG_APP_SERVERIP       ip  //网关IP地址

#define CONFIG_APP_HOSTPORT       8888

#define CONFIG_APP_SERVERPORT     port

#define CONFIG_APP_DEVICEID       id       //注册设备后生成的deviceid

#define CONFIG_QUEUE_TIMEOUT      (5*1000)

#define MSGQUEUE_OBJECTS 16 // number of Message Queue Objects

extern char ssid[50], ip[50], port[50],id[50];

osMessageQueueId_t mid_MsgQueue; // message queue id
typedef enum
{
    en_msg_cmd = 0,
    en_msg_report,
    en_msg_conn,
    en_msg_disconn,
}en_msg_type_t;

enum{
    button_off,     //按键状态：关
    button_on       //按键状态：开
}F1_flag, F2_flag;

typedef struct
{
    char *request_id;
    char *payload;
} cmd_t;

typedef struct
{
    char *motor_status;
    int smoke;
    int temp;
    int hum;
    int lum;
} report_t;

typedef struct
{
    en_msg_type_t msg_type;
    union
    {
        cmd_t cmd;
        report_t report;
    } msg;
} app_msg_t;

typedef struct
{
    queue_t                     *app_msg;
    E53_IA1_Status_ENUM          connected;
    E53_IA1_Status_ENUM          led;
    E53_IA1_Status_ENUM          motor;
}app_cb_t;

static app_cb_t  g_app_cb;
osEventFlagsId_t evt_id;
osSemaphoreId_t sem1;

/**************************************************
 * 任务：F1_Pressed
 * F1按键回调
 * ***********************************************/
static void F1_Pressed(char *arg)
{
    (void)arg;
    F1_flag = button_on;    
    osEventFlagsSet(evt_id, 0x00000001U);
}

/**************************************************
 * 任务：F2_Pressed
 * F2按键回调
 * ***********************************************/
static void F2_Pressed(char *arg)
{
    (void)arg;
    F2_flag = button_on;
    osEventFlagsSet(evt_id, 0x00000001U); 
}

/**************************************************
 * 任务：button_init
 * 按键硬件初始化
 * ***********************************************/
static void button_init(void)
{
    GpioInit();
    
        //初始化F1按键，设置为下降沿触发中断
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_IO_FUNC_GPIO_11_GPIO);

    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_GPIO_DIR_IN);
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_IO_PULL_UP);
    GpioRegisterIsrFunc(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_INT_TYPE_EDGE, WIFI_IOT_GPIO_EDGE_FALL_LEVEL_LOW, F1_Pressed, NULL);

    //初始化F2按键，设置为下降沿触发中断
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_FUNC_GPIO_12_GPIO);

    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_GPIO_DIR_IN);
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_PULL_UP);
    GpioRegisterIsrFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_INT_TYPE_EDGE, WIFI_IOT_GPIO_EDGE_FALL_LEVEL_LOW, F2_Pressed, NULL);

}

/**************************************************
 * 任务：button_task_entry
 * 按键处理任务
 * ***********************************************/
static int button_task_entry(void)
{    
    uint8_t Motor_Status, Light_Status;

    /* 按键硬件初始化 */
    button_init();

    /* 创建按键事件 */
    evt_id = osEventFlagsNew(NULL);
    if (evt_id == NULL)
    {
        printf("Falied to create EventFlags!\n");
    }

    /* 等待按键事件 */
    while (1)
    {
        osEventFlagsWait(evt_id, 0x00000001U, osFlagsWaitAny, osWaitForever);
        if(F1_flag == button_on)
        {
            osDelay(20);
            if(F1_flag == button_on)
            {
                F1_flag = button_off;
                if(g_app_cb.led == OFF)
                {
                    g_app_cb.led = ON;
                    Light_StatusSet(ON);    //开灯
                }
                else
                {
                    g_app_cb.led = OFF;
                    Light_StatusSet(OFF);   //关灯
                }
            }            
        }

        if(F2_flag == button_on)
        {
            osDelay(20);
            if(F2_flag == button_on)
            {
                F2_flag = button_off;
                if(g_app_cb.motor == OFF)
                {
                    g_app_cb.motor = ON;
                    Motor_StatusSet(ON);    //开电机
                }
                else
                {
                    g_app_cb.motor = OFF;
                    Motor_StatusSet(OFF);   //关电机
                }
            }            
        }
    }
    return 0;
}


static void deal_report_msg(report_t *report)
{

    //构造发送的数据
    cJSON * item;
    item = cJSON_CreateObject();    //创建根数据对象
    cJSON_AddStringToObject(item,"id",CONFIG_APP_DEVICEID);  //加入键值，加字符串
    cJSON_AddNumberToObject(item,"Smoke",report->smoke);  //加数字类型
    cJSON_AddNumberToObject(item,"Luminance",report->lum);  //加数字类型
    cJSON_AddNumberToObject(item,"Temperature",report->temp);  //加数字类型
    cJSON_AddNumberToObject(item,"Humidity",report->hum);  //加数字类型
    cJSON_AddStringToObject(item,"Motor",report->motor_status);  //加入键值，加字符串
    char *send_data = cJSON_PrintUnformatted(item);
    printf("send report data: %s\n", send_data);
    cJSON_Delete(item); 
    free(item); // isequal

    //线程休眠一段时间
    osDelay(100);

    //UDP数据发送
    int sock_fd;
    //服务器的地址信息
    struct sockaddr_in send_addr;
    socklen_t addr_length = sizeof(send_addr);


      //创建socket
    if ((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    {
        perror("create socket failed!\r\n");
        exit(1);
    }

    //初始化预连接的服务端地址
    send_addr.sin_family = AF_INET;
    send_addr.sin_port = htons(atoi(CONFIG_APP_SERVERPORT));
    send_addr.sin_addr.s_addr = inet_addr(CONFIG_APP_SERVERIP);
    addr_length = sizeof(send_addr);


    //发送数据到服务远端
    sendto(sock_fd, send_data, strlen(send_data), 0, (struct sockaddr *)&send_addr, addr_length);

    //接收服务端返回的字符串
    //recvfrom(sock_fd, recvBuf, sizeof(recvBuf), 0, (struct sockaddr *)&send_addr, &addr_length);
    printf("%s:%d=>\n", inet_ntoa(send_addr.sin_addr), ntohs(send_addr.sin_port));

    //关闭这个 socket
    closesocket(sock_fd);
    osSemaphoreRelease(sem1);
    return;
}

static void UDPServerTask(void)
{
    //等待wifi连接
    while(g_app_cb.connected == OFF)
    osDelay(100);
    
    char recvbuf[50]={0};
    char payload[50]={0};
    int sock_fd;
    	//服务端地址信息
	struct sockaddr_in server_sock;

	//客户端地址信息
	struct sockaddr_in client_sock;
	int sin_size;

	struct sockaddr_in *cli_addr;

    //创建socket
	if ((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
		perror("socket is error\r\n");
		exit(1);
	}

	bzero(&server_sock, sizeof(server_sock));
	server_sock.sin_family = AF_INET;
	server_sock.sin_addr.s_addr = htonl(INADDR_ANY);
	server_sock.sin_port = htons(CONFIG_APP_HOSTPORT);

	//调用bind函数绑定socket和地址
	if (bind(sock_fd, (struct sockaddr *)&server_sock, sizeof(struct sockaddr)) == -1)
	{
		perror("bind is error\r\n");
		exit(1);
	}

    //把收到的数据放进消息队列
    sin_size = sizeof(struct sockaddr_in);
	ssize_t ret;
    app_msg_t *app_msg;

	while (1)
	{
        app_msg = malloc(sizeof(app_msg_t));
		if ((ret = recvfrom(sock_fd, recvbuf, sizeof(recvbuf), 0,(struct sockaddr *)&client_sock, (socklen_t *)&sin_size)) == -1)
		{
			printf("recv error \r\n");
		}
		printf("recv :%s\r\n", recvbuf);

        strcpy(payload,recvbuf);

        if (NULL != app_msg)
        {

            app_msg->msg_type = en_msg_cmd;
            app_msg->msg.cmd.request_id = NULL;
            app_msg->msg.cmd.payload = payload;
            if(0 != queue_push(g_app_cb.app_msg,app_msg,CONFIG_QUEUE_TIMEOUT)){
                free(app_msg);
            }
        }
        bzero(recvbuf, sizeof(recvbuf));
		//sleep(2);
		if ((ret = sendto(sock_fd, "OK", strlen("OK") + 1, 0,(struct sockaddr *)&client_sock,sizeof(client_sock))) == -1)
		{
			perror("send ok error ");
		}

		//sleep(2);
	}

	close(sock_fd);
    return;
}


///< COMMAND DEAL
static void deal_cmd_msg(cmd_t *cmd)
{
    cJSON *obj_root;
    cJSON *obj_cmd;
    //处理json数据
    obj_root = cJSON_Parse(cmd->payload);
    if (NULL == obj_root)
    {
        printf("Cmd Error: [%s]\n", obj_root);
        return;
    }

    obj_cmd = cJSON_GetObjectItem(obj_root, "motor_control");
    if (NULL == obj_cmd)
    {
        goto EXIT;
    }
    if (0 == strcmp(cJSON_GetStringValue(obj_cmd), "ON"))
    {
            
        g_app_cb.motor = ON;
        Motor_StatusSet(ON);
        printf("Motor On!\r\n");

        g_app_cb.led = ON;
        Light_StatusSet(ON);
        printf("Light On!\r\n");
    }
    else if (0 == strcmp(cJSON_GetStringValue(obj_cmd), "OFF"))
    {
        g_app_cb.motor = OFF;
        Motor_StatusSet(OFF);
        printf("Motor Off!\r\n");

        g_app_cb.led = OFF;
        Light_StatusSet(OFF);
        printf("Light Off!\r\n");
    }

    EXIT:
    cJSON_Delete(obj_root);
    free(obj_root); // isequal
    bzero(cmd->payload, sizeof(cmd->payload));
    return;
}


static int task_main_entry(void)
{
    app_msg_t *app_msg;
    /* 从NFC中读取连接平台相关设备信息 */
    while (nfc_get_devived_data() == 1){
        printf("Json format error,init failed\r\n");
        osDelay(100);
    }

    WifiConnect(CONFIG_WIFI_SSID, CONFIG_WIFI_PWD);
    g_app_cb.connected = ON; //wifi已经连接
    Led_StatusSet(ON); //连接网络指示灯亮
    
    while (1)
    {
        app_msg = NULL;
        (void)queue_pop(g_app_cb.app_msg,(void **)&app_msg,0xFFFFFFFF);
        if(NULL != app_msg){
            switch(app_msg->msg_type){
                case en_msg_cmd:
                    deal_cmd_msg(&app_msg->msg.cmd);
                    break;
                case en_msg_report:
                    deal_report_msg(&app_msg->msg.report);
                    break;
                default:
                    break;
            }
            free(app_msg);
        }
    }
    return 0;
}

static int task_sensor_entry(void)
{
    app_msg_t *app_msg;
    E53_IA1_Data_TypeDef data;
    E53_IA1_Init();
    /****传感器校准****/
    usleep(1000000);        // 开机1s后进行校准
    MQ2_PPM_Calibration();  // 校准传感器

    Motor_StatusSet(OFF);
    Light_StatusSet(OFF);   //初始化电机和led灯状态
    Led_StatusSet(OFF);

    g_app_cb.motor = OFF;
    g_app_cb.led = OFF;
    while (1)
    {
        E53_IA1_Read_Data(&data);
        app_msg = malloc(sizeof(app_msg_t));
        printf("SENSOR:smoke:%.2f lum:%.2f temp:%.2f hum:%.2f\r\n", data.Smoke, data.Luminance, data.Temperature, data.Humidity);
        if (NULL != app_msg)
        {
            app_msg->msg_type = en_msg_report;
            app_msg->msg.report.hum = (int)data.Humidity;
            app_msg->msg.report.smoke = (int)data.Smoke;
            app_msg->msg.report.lum = (int)data.Luminance;
            app_msg->msg.report.temp = (int)data.Temperature;
            app_msg->msg.report.motor_status = (g_app_cb.motor == ON) ? "ON" : "OFF";
            if(0 != queue_push(g_app_cb.app_msg,app_msg,CONFIG_QUEUE_TIMEOUT)){
                free(app_msg);
            }
        }
        //sleep(3);
        osSemaphoreAcquire(sem1, osWaitForever);
    }
    return 0;
}

static void OC_Demo(void)
{
    g_app_cb.app_msg = queue_create("queue_rcvmsg",10,1);
    if(NULL ==  g_app_cb.app_msg){
        printf("Create receive msg queue failed");
        
    }

    osThreadAttr_t attr;

    attr.name = "task_main_entry";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 10240;
    attr.priority = 24;

    if (osThreadNew((osThreadFunc_t)task_main_entry, NULL, &attr) == NULL)
    {
        printf("Falied to create task_main_entry!\n");
    }
    attr.stack_size = 2048;
    attr.priority = 25;
    attr.name = "task_sensor_entry";
    if (osThreadNew((osThreadFunc_t)task_sensor_entry, NULL, &attr) == NULL)
    {
        printf("Falied to create task_sensor_entry!\n");
    }

    attr.stack_size = 2048;
    attr.priority = 25;
    attr.name = "UDPServerTask";
    if (osThreadNew((osThreadFunc_t)UDPServerTask, NULL, &attr) == NULL)
    {
        printf("Falied to create UDPServerTask!\n");
    }

        /* 创建本地按键控制任务 */
    attr.name = "button_task_entry";
    attr.priority = 26;
    if (osThreadNew((osThreadFunc_t)button_task_entry, NULL, &attr) == NULL)
    {
        printf("Falied to create button_task_entry!\n");
    }

    sem1 = osSemaphoreNew(4, 0, NULL);
    if (sem1 == NULL)
    {
        printf("Falied to create Semaphore1!\n");
    }
}

APP_FEATURE_INIT(OC_Demo);
