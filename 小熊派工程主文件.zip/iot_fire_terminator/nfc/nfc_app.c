#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "nfc_app.h"
#include "NT3H.h"
#include <cJSON.h>


char ssid[50], port[50], id[50];
/**************************************************
 * get_devived_data
 * 获取WiFi的ssid和密钥及设备DevicesID和密钥
 * ***********************************************/
uint8_t nfc_get_devived_data(void)
{
    uint8_t memary_buf[16 * 15];
    cJSON *json, *jsonTemp; // *jsonArray,
    uint8_t jsonbuf[512] = {0};
    char jsonbuf_string[512] = {0};
    uint8_t payload_len = 0;

    NT3H1101_Read_Userpages(50, memary_buf);
    payload_len = memary_buf[4];
    //取出真实的json数据包
    for (uint8_t i = 0; i < payload_len; i++)
    {
        jsonbuf[i] = memary_buf[9 + i];
    }

    memset(memary_buf, 0x00, sizeof(memary_buf));
    sprintf(jsonbuf_string, "%s", jsonbuf);
    printf("jsonbuf: %s\n", jsonbuf);
    //解析json数据
    json = cJSON_Parse(jsonbuf_string);
    if (!json)
    {
        printf("Nfc Error: [%s]\n", jsonbuf_string);
        return 1;
    }
    else
    {
        jsonTemp = cJSON_GetObjectItem(json, "ssid");
	if(!jsonTemp) return 1;
        memset(ssid, 0, sizeof(ssid));
        snprintf(ssid, strlen(jsonTemp->valuestring) + 1, "%s", jsonTemp->valuestring);
        jsonTemp = cJSON_GetObjectItem(json, "port");
	if(!jsonTemp) return 1;
        memset(port, 0, sizeof(port));
        snprintf(port, strlen(jsonTemp->valuestring) + 1, "%s", jsonTemp->valuestring);
        jsonTemp = cJSON_GetObjectItem(json, "id");
	if(!jsonTemp) return 1;
        memset(id, 0, sizeof(id));
        snprintf(id, strlen(jsonTemp->valuestring) + 1, "%s", jsonTemp->valuestring);

        printf("ssid: %s, port: %s ,id: %s \r\n",ssid,port,id);

        cJSON_Delete(json);
        free(json); // isequal
    }
    return 0;
}
