#ifndef __NFC_APP_H__
#define __NFC_APP_H__

#include "nfc.h"

uint8_t nfc_get_devived_data(void);

#endif