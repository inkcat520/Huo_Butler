#ifndef NDEF_H_
#define NDEF_H_

#include "NT3H.h"

bool NT3HwriteRecord(const NDEFDataStr *data);


#endif /* NDEF_H_ */